import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:graduation_progect/core/theming/app_colors.dart';
import 'package:graduation_progect/features/shared_screens/shipment_details/models/shipment_details_response.dart';
import 'package:graduation_progect/features/shared_screens/shipment_details/ui/widgets/shipment_map_widget.dart';

// ─── Main Content Widget ──────────────────────────────────────────────────────

class ShipmentDetailsContent extends StatelessWidget {
  final ShipmentDetailsResponse data;

  const ShipmentDetailsContent({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final shipment = data.shipment;
    final driver = data.driver;
    final client = data.client;
    final geometry = data.route_geometry;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isCompleted = shipment.success == 1;

    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        // ── Sliver AppBar ──
        _ShipmentSliverAppBar(
          shipment: shipment,
          isDark: isDark,
          isCompleted: isCompleted,
        ),

        SliverPadding(
          padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 32.h),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              SizedBox(height: 16.h),

              // ── Shipment Number + Status row ──
              _ShipmentHeaderCard(shipment: shipment, isDark: isDark),
              SizedBox(height: 12.h),

              // ── PIN + QR row (if available) ──
              if (shipment.pin != null || shipment.qrPin != null) ...[
                _PinQrRow(
                  pin: shipment.pin,
                  qrPin: shipment.qrPin,
                  isDark: isDark,
                ),
                SizedBox(height: 12.h),
              ],

              // ── Route Card ──
              _SectionLabel(label: 'مسار الشحنة', icon: Icons.route_rounded),
              SizedBox(height: 8.h),
              _RouteCard(
                startGovernorate: shipment.startGovernorate,
                endGovernorate: shipment.endGovernorate,
                isDark: isDark,
              ),
              SizedBox(height: 12.h),

              // ── Map Preview Card ──
              _SectionLabel(label: 'الخريطة', icon: Icons.map_rounded),
              SizedBox(height: 8.h),
              ShipmentMapWidget(
                geometry: geometry,
                startLat: shipment.startPositionLat,
                startLng: shipment.startPositionLng,
                endLat: shipment.endPositionLat,
                endLng: shipment.endPositionLng,
              ),
              SizedBox(height: 12.h),

              // ── Shipment Details Card ──
              _SectionLabel(
                  label: 'تفاصيل الشحنة', icon: Icons.inventory_2_outlined),
              SizedBox(height: 8.h),
              _ShipmentDetailsCard(shipment: shipment, isDark: isDark),
              SizedBox(height: 12.h),

              // ── Status Card ──
              _SectionLabel(
                  label: 'حالة الشحنة', icon: Icons.info_outline_rounded),
              SizedBox(height: 8.h),
              _StatusCard(shipment: shipment, isDark: isDark),
              SizedBox(height: 12.h),

              // ── Parties ──
              if (driver != null || client != null) ...[
                _SectionLabel(
                    label: 'الأطراف', icon: Icons.people_outline_rounded),
                SizedBox(height: 8.h),
                if (driver != null) ...[
                  _PartyCard(party: driver, role: 'السائق', isDark: isDark,
                      icon: Icons.drive_eta_outlined,
                      iconColor: AppColors.primary),
                  SizedBox(height: 8.h),
                ],
                if (client != null)
                  _PartyCard(party: client, role: 'العميل', isDark: isDark,
                      icon: Icons.person_outline_rounded,
                      iconColor: AppColors.secondary),
              ],
            ]),
          ),
        ),
      ],
    );
  }
}

// ─── Sliver AppBar ────────────────────────────────────────────────────────────

class _ShipmentSliverAppBar extends StatelessWidget {
  final ShipmentDetail shipment;
  final bool isDark, isCompleted;

  const _ShipmentSliverAppBar({
    required this.shipment,
    required this.isDark,
    required this.isCompleted,
  });

  @override
  Widget build(BuildContext context) {
    final statusColor = isCompleted ? AppColors.success : AppColors.secondary;
    final bgSurface =
        isDark ? AppColors.darkSurface : AppColors.lightSurface;

    return SliverAppBar(
      expandedHeight: 0,
      floating: true,
      snap: true,
      pinned: true,
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.lightBackground,
      elevation: 0,
      scrolledUnderElevation: 0.5,
      shadowColor: Colors.black.withValues(alpha: 0.08),
      leading: Padding(
        padding: EdgeInsets.only(right: 8.w),
        child: _GlassIconButton(
          icon: Icons.arrow_back_ios_new_rounded,
          isDark: isDark,
          onTap: () => Navigator.pop(context),
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'تفاصيل الشحنة',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.3,
                ),
          ),
          Row(
            children: [
              Container(
                width: 6.w,
                height: 6.w,
                decoration: BoxDecoration(
                  color: statusColor,
                  shape: BoxShape.circle,
                ),
              ),
              SizedBox(width: 4.w),
              Text(
                shipment.status ??
                    (isCompleted ? 'مكتملة' : 'قيد التنفيذ'),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: statusColor,
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),
        ],
      ),
      actions: [
        _GlassIconButton(
          icon: Icons.share_rounded,
          isDark: isDark,
          onTap: () {
            // TODO: Share shipment details
          },
        ),
        SizedBox(width: 8.w),
      ],
    );
  }
}

// ─── Glass Icon Button ────────────────────────────────────────────────────────

class _GlassIconButton extends StatelessWidget {
  final IconData icon;
  final bool isDark;
  final VoidCallback? onTap;

  const _GlassIconButton(
      {required this.icon, required this.isDark, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38.w,
        height: 38.w,
        decoration: BoxDecoration(
          color: isDark
              ? Colors.white.withValues(alpha: 0.08)
              : Colors.black.withValues(alpha: 0.05),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: isDark
                ? Colors.white.withValues(alpha: 0.1)
                : Colors.black.withValues(alpha: 0.06),
          ),
        ),
        child: Icon(icon,
            size: 18.sp,
            color: isDark
                ? AppColors.darkTextPrimary
                : AppColors.lightTextPrimary),
      ),
    );
  }
}

// ─── Section Label ────────────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String label;
  final IconData icon;

  const _SectionLabel({required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 16.sp, color: AppColors.primary),
        SizedBox(width: 6.w),
        Text(
          label,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: AppColors.primary,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.2,
              ),
        ),
      ],
    );
  }
}

// ─── Shipment Header Card ─────────────────────────────────────────────────────

class _ShipmentHeaderCard extends StatelessWidget {
  final ShipmentDetail shipment;
  final bool isDark;

  const _ShipmentHeaderCard(
      {required this.shipment, required this.isDark});

  @override
  Widget build(BuildContext context) {
    final isCompleted = shipment.success == 1;
    final statusColor = isCompleted ? AppColors.success : AppColors.secondary;
    final surface =
        isDark ? AppColors.darkSurface : AppColors.lightSurface;
    final border =
        isDark ? AppColors.darkBorder : AppColors.lightBorder;

    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // Ship icon container
          Container(
            width: 52.w,
            height: 52.w,
            decoration: BoxDecoration(
              color: statusColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14.r),
            ),
            child: Icon(Icons.local_shipping_rounded,
                color: statusColor, size: 26.sp),
          ),
          SizedBox(width: 14.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      'شحنة #${shipment.shipmentNumber}',
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const Spacer(),
                    _CopyChip(
                      value: shipment.shipmentNumber.toString(),
                      label: 'نسخ',
                      isDark: isDark,
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Container(
                  padding: EdgeInsets.symmetric(
                      horizontal: 10.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8.r),
                    border:
                        Border.all(color: statusColor.withValues(alpha: 0.3)),
                  ),
                  child: Text(
                    shipment.status ??
                        (isCompleted ? 'مكتملة' : 'قيد التنفيذ'),
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Copy Chip ────────────────────────────────────────────────────────────────

class _CopyChip extends StatefulWidget {
  final String value;
  final String label;
  final bool isDark;

  const _CopyChip(
      {required this.value, required this.label, required this.isDark});

  @override
  State<_CopyChip> createState() => _CopyChipState();
}

class _CopyChipState extends State<_CopyChip>
    with SingleTickerProviderStateMixin {
  bool _copied = false;
  late final AnimationController _ctrl;
  late final Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 200));
    _scaleAnim =
        Tween<double>(begin: 1.0, end: 0.88).animate(
            CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _copy() async {
    await _ctrl.forward();
    await _ctrl.reverse();
    await Clipboard.setData(ClipboardData(text: widget.value));
    setState(() => _copied = true);
    HapticFeedback.lightImpact();
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) setState(() => _copied = false);
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scaleAnim,
      child: GestureDetector(
        onTap: _copy,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
          decoration: BoxDecoration(
            color: _copied
                ? AppColors.success.withValues(alpha: 0.12)
                : (widget.isDark
                    ? Colors.white.withValues(alpha: 0.07)
                    : AppColors.primary.withValues(alpha: 0.07)),
            borderRadius: BorderRadius.circular(8.r),
            border: Border.all(
              color: _copied
                  ? AppColors.success.withValues(alpha: 0.4)
                  : (widget.isDark
                      ? Colors.white.withValues(alpha: 0.1)
                      : AppColors.primary.withValues(alpha: 0.2)),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                _copied
                    ? Icons.check_rounded
                    : Icons.copy_rounded,
                size: 12.sp,
                color: _copied ? AppColors.success : AppColors.primary,
              ),
              SizedBox(width: 4.w),
              Text(
                _copied ? 'تم!' : widget.label,
                style: TextStyle(
                  fontSize: 11.sp,
                  fontWeight: FontWeight.w600,
                  color: _copied ? AppColors.success : AppColors.primary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── PIN + QR Row ─────────────────────────────────────────────────────────────

class _PinQrRow extends StatelessWidget {
  final String? pin;
  final String? qrPin;
  final bool isDark;

  const _PinQrRow({this.pin, this.qrPin, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (pin != null)
          Expanded(
            child: _PinCard(pin: pin!, isDark: isDark),
          ),
        if (pin != null && qrPin != null) SizedBox(width: 10.w),
        if (qrPin != null)
          _QrButton(qrPin: qrPin!, isDark: isDark),
      ],
    );
  }
}

// ─── PIN Card ─────────────────────────────────────────────────────────────────

class _PinCard extends StatefulWidget {
  final String pin;
  final bool isDark;

  const _PinCard({required this.pin, required this.isDark});

  @override
  State<_PinCard> createState() => _PinCardState();
}

class _PinCardState extends State<_PinCard> {
  bool _hidden = true;
  bool _copied = false;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.pin));
    HapticFeedback.lightImpact();
    setState(() => _copied = true);
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) setState(() => _copied = false);
  }

  @override
  Widget build(BuildContext context) {
    final surface =
        widget.isDark ? AppColors.darkSurface : AppColors.lightSurface;
    final border =
        widget.isDark ? AppColors.darkBorder : AppColors.lightBorder;

    return Container(
      padding: EdgeInsets.all(14.w),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: widget.isDark ? 0.2 : 0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30.w,
                height: 30.w,
                decoration: BoxDecoration(
                  color: AppColors.primary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Icon(Icons.pin_outlined,
                    size: 16.sp, color: AppColors.primary),
              ),
              SizedBox(width: 8.w),
              Text(
                'رمز PIN',
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      color: widget.isDark
                          ? AppColors.darkTextSecondary
                          : AppColors.lightTextSecondary,
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),
          SizedBox(height: 10.h),
          Row(
            children: [
              Expanded(
                child: Text(
                  _hidden
                      ? '•' * math.min(widget.pin.length, 6)
                      : widget.pin,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                        letterSpacing: 3,
                        color: AppColors.primary,
                      ),
                ),
              ),
              GestureDetector(
                onTap: () => setState(() => _hidden = !_hidden),
                child: Icon(
                  _hidden
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  size: 18.sp,
                  color: widget.isDark
                      ? AppColors.darkTextSecondary
                      : AppColors.lightTextSecondary,
                ),
              ),
            ],
          ),
          SizedBox(height: 10.h),
          GestureDetector(
            onTap: _copy,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 9.h),
              decoration: BoxDecoration(
                color: _copied
                    ? AppColors.success
                    : AppColors.primary,
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _copied ? Icons.check_rounded : Icons.copy_rounded,
                    size: 14.sp,
                    color: Colors.white,
                  ),
                  SizedBox(width: 6.w),
                  Text(
                    _copied ? 'تم النسخ' : 'نسخ الـ PIN',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── QR Button ────────────────────────────────────────────────────────────────

class _QrButton extends StatelessWidget {
  final String qrPin;
  final bool isDark;

  const _QrButton({required this.qrPin, required this.isDark});

  @override
  Widget build(BuildContext context) {
    final surface =
        isDark ? AppColors.darkSurface : AppColors.lightSurface;
    final border = isDark ? AppColors.darkBorder : AppColors.lightBorder;

    return GestureDetector(
      onTap: () => _showQrModal(context),
      child: Container(
        width: 100.w,
        padding: EdgeInsets.all(14.w),
        decoration: BoxDecoration(
          color: surface,
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(color: AppColors.primary.withValues(alpha: 0.3)),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withValues(alpha: 0.1),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 40.w,
              height: 40.w,
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Icon(Icons.qr_code_2_rounded,
                  size: 24.sp, color: AppColors.primary),
            ),
            SizedBox(height: 8.h),
            Text(
              'عرض QR',
              style: TextStyle(
                color: AppColors.primary,
                fontSize: 11.sp,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            Text(
              'اضغط للفتح',
              style: TextStyle(
                color: isDark
                    ? AppColors.darkTextSecondary
                    : AppColors.lightTextSecondary,
                fontSize: 9.sp,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _showQrModal(BuildContext context) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _QrBottomSheet(qrPin: qrPin),
    );
  }
}

// ─── QR Bottom Sheet ──────────────────────────────────────────────────────────

class _QrBottomSheet extends StatelessWidget {
  final String qrPin;

  const _QrBottomSheet({required this.qrPin});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? AppColors.darkSurface : AppColors.lightSurface;

    return Container(
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28.r)),
      ),
      padding: EdgeInsets.fromLTRB(24.w, 16.h, 24.w, 40.h),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Container(
            width: 40.w,
            height: 4.h,
            decoration: BoxDecoration(
              color: isDark
                  ? Colors.white.withValues(alpha: 0.15)
                  : Colors.black.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(2.r),
            ),
          ),
          SizedBox(height: 24.h),
          Text(
            'رمز QR الخاص بشحنتك',
            style: Theme.of(context)
                .textTheme
                .titleLarge
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
          SizedBox(height: 6.h),
          Text(
            'أظهر هذا الرمز للسائق لتأكيد استلام الشحنة',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: isDark
                      ? AppColors.darkTextSecondary
                      : AppColors.lightTextSecondary,
                ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 32.h),

          // QR Code display area
          Container(
            padding: EdgeInsets.all(20.w),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20.r),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.12),
                  blurRadius: 20,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              children: [
                // QR placeholder - replace with qr_flutter widget
                Container(
                  width: 200.w,
                  height: 200.w,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: _QrCodePlaceholder(data: qrPin),
                ),
                SizedBox(height: 14.h),
                Text(
                  qrPin,
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 4,
                    color: AppColors.lightTextPrimary,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 28.h),

          // Action buttons
          Row(
            children: [
              Expanded(
                child: _ActionButton(
                  icon: Icons.copy_rounded,
                  label: 'نسخ الرمز',
                  color: isDark
                      ? AppColors.darkBorder
                      : AppColors.lightBorder,
                  textColor: isDark
                      ? AppColors.darkTextPrimary
                      : AppColors.lightTextPrimary,
                  onTap: () async {
                    await Clipboard.setData(ClipboardData(text: qrPin));
                    HapticFeedback.lightImpact();
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text('تم نسخ رمز QR'),
                          backgroundColor: AppColors.success,
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.r)),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    }
                  },
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: _ActionButton(
                  icon: Icons.share_rounded,
                  label: 'مشاركة',
                  color: AppColors.primary,
                  textColor: Colors.white,
                  onTap: () {
                    // TODO: Share QR image via share_plus
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─── QR Code Placeholder ─────────────────────────────────────────────────────
// استبدلها بـ QrImageView من حزمة qr_flutter

class _QrCodePlaceholder extends StatelessWidget {
  final String data;
  const _QrCodePlaceholder({required this.data});

  @override
  Widget build(BuildContext context) {
    // TODO: استبدل هذا بـ:
    // QrImageView(data: data, version: QrVersions.auto, size: 200.w)
    // بعد إضافة: qr_flutter: ^4.1.0 في pubspec.yaml
    return Stack(
      alignment: Alignment.center,
      children: [
        CustomPaint(
          size: Size(200.w, 200.w),
          painter: _QrPatternPainter(),
        ),
        Container(
          padding: EdgeInsets.all(8.w),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8.r),
          ),
          child: Icon(Icons.qr_code_2_rounded,
              size: 32.sp, color: AppColors.primary),
        ),
      ],
    );
  }
}

class _QrPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black87
      ..style = PaintingStyle.fill;

    const int cells = 21;
    final cellSize = size.width / cells;

    // Draw finder patterns (corners)
    void drawFinder(double x, double y) {
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(x, y, cellSize * 7, cellSize * 7),
              const Radius.circular(2)),
          paint);
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(
                  x + cellSize, y + cellSize, cellSize * 5, cellSize * 5),
              const Radius.circular(1)),
          Paint()
            ..color = Colors.white
            ..style = PaintingStyle.fill);
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(
                  x + cellSize * 2, y + cellSize * 2, cellSize * 3, cellSize * 3),
              const Radius.circular(1)),
          paint);
    }

    drawFinder(0, 0);
    drawFinder((cells - 7) * cellSize, 0);
    drawFinder(0, (cells - 7) * cellSize);

    // Simulate random data cells
    // final rand = math.Random(data.hashCode);
    for (int r = 0; r < cells; r++) {
      for (int c = 0; c < cells; c++) {
        if (r < 8 && (c < 8 || c >= cells - 8)) continue;
        if (r >= cells - 8 && c < 8) continue;
        // if (rand.nextBool()) {
        //   canvas.drawRect(
        //       Rect.fromLTWH(c * cellSize + 0.5, r * cellSize + 0.5,
        //           cellSize - 1, cellSize - 1),
        //       paint);
        // }
      }
    }
  }

  @override
  bool shouldRepaint(_QrPatternPainter old) => false;
}

// ─── Action Button ────────────────────────────────────────────────────────────

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final Color textColor;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.textColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 14.h),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(14.r),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: textColor, size: 16.sp),
            SizedBox(width: 6.w),
            Text(
              label,
              style: TextStyle(
                color: textColor,
                fontWeight: FontWeight.w700,
                fontSize: 14.sp,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Route Card ──────────────────────────────────────────────────────────────

class _RouteCard extends StatelessWidget {
  final String startGovernorate;
  final String endGovernorate;
  final bool isDark;

  const _RouteCard({
    required this.startGovernorate,
    required this.endGovernorate,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final surface =
        isDark ? AppColors.darkSurface : AppColors.lightSurface;
    final border =
        isDark ? AppColors.darkBorder : AppColors.lightBorder;

    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          // Start
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 8.w,
                      height: 8.w,
                      decoration: BoxDecoration(
                        color: AppColors.success,
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: AppColors.success.withValues(alpha: 0.4),
                            width: 2),
                      ),
                    ),
                    SizedBox(width: 6.w),
                    Text(
                      'نقطة الانطلاق',
                      style: TextStyle(
                        fontSize: 10.sp,
                        color: isDark
                            ? AppColors.darkTextSecondary
                            : AppColors.lightTextSecondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Text(
                  startGovernorate,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                ),
              ],
            ),
          ),

          // Arrow
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 12.w),
            child: Column(
              children: [
                Icon(Icons.arrow_forward_rounded,
                    size: 20.sp,
                    color: isDark
                        ? AppColors.darkTextSecondary
                        : AppColors.lightTextSecondary),
              ],
            ),
          ),

          // End
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'الوجهة',
                      style: TextStyle(
                        fontSize: 10.sp,
                        color: isDark
                            ? AppColors.darkTextSecondary
                            : AppColors.lightTextSecondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(width: 6.w),
                    Container(
                      width: 8.w,
                      height: 8.w,
                      decoration: BoxDecoration(
                        color: AppColors.error,
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: AppColors.error.withValues(alpha: 0.4),
                            width: 2),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Text(
                  endGovernorate,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                  textAlign: TextAlign.end,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Shipment Details Card ───────────────────────────────────────────────────

class _ShipmentDetailsCard extends StatelessWidget {
  final ShipmentDetail shipment;
  final bool isDark;

  const _ShipmentDetailsCard(
      {required this.shipment, required this.isDark});

  @override
  Widget build(BuildContext context) {
    final surface =
        isDark ? AppColors.darkSurface : AppColors.lightSurface;
    final border =
        isDark ? AppColors.darkBorder : AppColors.lightBorder;
    final secondaryText = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;

    final hasDimensions = shipment.width != null ||
        shipment.height != null ||
        shipment.length != null;

    return Container(
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          // Price — hero element
          Container(
            padding: EdgeInsets.all(16.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppColors.primary,
                  AppColors.primaryDark,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.vertical(top: Radius.circular(16.r)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'السعر الإجمالي',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.75),
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        '${shipment.price ?? 0} ل.س',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24.sp,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                if (shipment.insurance != null &&
                    shipment.insurance! > 0) ...[
                  Container(
                    padding: EdgeInsets.symmetric(
                        horizontal: 12.w, vertical: 8.h),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10.r),
                    ),
                    child: Column(
                      children: [
                        Icon(Icons.security_rounded,
                            color: Colors.white, size: 16.sp),
                        SizedBox(height: 2.h),
                        Text(
                          '${shipment.insurance} ل.س',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          'تأمين',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.7),
                            fontSize: 9.sp,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),

          // Details rows
          Padding(
            padding: EdgeInsets.all(16.w),
            child: Column(
              children: [
                if (shipment.object != null) ...[
                  _InfoRow(
                    icon: Icons.inventory_2_outlined,
                    label: 'نوع المحمول',
                    value: shipment.object!,
                    isDark: isDark,
                  ),
                  _Divider(isDark: isDark),
                ],
                if (shipment.weight != null) ...[
                  _InfoRow(
                    icon: Icons.scale_outlined,
                    label: 'الوزن',
                    value: '${shipment.weight} كغم',
                    isDark: isDark,
                  ),
                  if (hasDimensions) _Divider(isDark: isDark),
                ],
                if (hasDimensions)
                  _DimensionsRow(shipment: shipment, isDark: isDark),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Info Row ─────────────────────────────────────────────────────────────────

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final bool isDark;

  const _InfoRow({
    required this.icon,
    required this.label,
    required this.value,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 34.w,
          height: 34.w,
          decoration: BoxDecoration(
            color: isDark
                ? Colors.white.withValues(alpha: 0.06)
                : Colors.black.withValues(alpha: 0.04),
            borderRadius: BorderRadius.circular(9.r),
          ),
          child: Icon(icon,
              size: 16.sp,
              color: isDark
                  ? AppColors.darkTextSecondary
                  : AppColors.lightTextSecondary),
        ),
        SizedBox(width: 12.w),
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 13.sp,
              color: isDark
                  ? AppColors.darkTextSecondary
                  : AppColors.lightTextSecondary,
            ),
          ),
        ),
        Text(
          value,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
        ),
      ],
    );
  }
}

class _Divider extends StatelessWidget {
  final bool isDark;
  const _Divider({required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Divider(
      height: 16.h,
      color: isDark
          ? AppColors.darkBorder
          : AppColors.lightBorder,
    );
  }
}

// ─── Dimensions Row ───────────────────────────────────────────────────────────

class _DimensionsRow extends StatelessWidget {
  final ShipmentDetail shipment;
  final bool isDark;

  const _DimensionsRow(
      {required this.shipment, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 34.w,
              height: 34.w,
              decoration: BoxDecoration(
                color: isDark
                    ? Colors.white.withValues(alpha: 0.06)
                    : Colors.black.withValues(alpha: 0.04),
                borderRadius: BorderRadius.circular(9.r),
              ),
              child: Icon(Icons.straighten_rounded,
                  size: 16.sp,
                  color: isDark
                      ? AppColors.darkTextSecondary
                      : AppColors.lightTextSecondary),
            ),
            SizedBox(width: 12.w),
            Text(
              'الأبعاد',
              style: TextStyle(
                fontSize: 13.sp,
                color: isDark
                    ? AppColors.darkTextSecondary
                    : AppColors.lightTextSecondary,
              ),
            ),
          ],
        ),
        SizedBox(height: 10.h),
        Wrap(
          spacing: 8.w,
          runSpacing: 8.h,
          children: [
            if (shipment.width != null)
              _DimChip(label: 'عرض', value: '${shipment.width} سم', isDark: isDark),
            if (shipment.height != null)
              _DimChip(label: 'ارتفاع', value: '${shipment.height} سم', isDark: isDark),
            if (shipment.length != null)
              _DimChip(label: 'طول', value: '${shipment.length} سم', isDark: isDark),
          ],
        ),
      ],
    );
  }
}

class _DimChip extends StatelessWidget {
  final String label, value;
  final bool isDark;

  const _DimChip(
      {required this.label, required this.value, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
      decoration: BoxDecoration(
        color: isDark
            ? AppColors.primary.withValues(alpha: 0.12)
            : AppColors.primary.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(8.r),
        border:
            Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
      ),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: '$label  ',
              style: TextStyle(
                fontSize: 10.sp,
                color: isDark
                    ? AppColors.darkTextSecondary
                    : AppColors.lightTextSecondary,
              ),
            ),
            TextSpan(
              text: value,
              style: TextStyle(
                fontSize: 12.sp,
                fontWeight: FontWeight.w700,
                color: AppColors.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Status Card ─────────────────────────────────────────────────────────────

class _StatusCard extends StatelessWidget {
  final ShipmentDetail shipment;
  final bool isDark;

  const _StatusCard({required this.shipment, required this.isDark});

  @override
  Widget build(BuildContext context) {
    final surface =
        isDark ? AppColors.darkSurface : AppColors.lightSurface;
    final border =
        isDark ? AppColors.darkBorder : AppColors.lightBorder;

    final isPaid = shipment.paid == 1;
    final isCompleted = shipment.success == 1;

    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          _InfoRow(
            icon: Icons.calendar_today_outlined,
            label: 'تاريخ التسليم',
            value: _formatDate(shipment.deliveryDeadline),
            isDark: isDark,
          ),
          _Divider(isDark: isDark),
          Row(
            children: [
              Expanded(
                child: _StatusBadge(
                  icon: Icons.payments_outlined,
                  label: isPaid ? 'مدفوع' : 'غير مدفوع',
                  color: isPaid ? AppColors.success : AppColors.warning,
                  isDark: isDark,
                ),
              ),
              SizedBox(width: 10.w),
              Expanded(
                child: _StatusBadge(
                  icon: Icons.check_circle_outline_rounded,
                  label: isCompleted ? 'مكتملة' : 'قيد التنفيذ',
                  color: isCompleted ? AppColors.success : AppColors.secondary,
                  isDark: isDark,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatDate(String? dateString) {
    if (dateString == null) return 'غير محدد';
    try {
      final parts = dateString.split(' ');
      if (parts.length >= 2) {
        final date = parts[0].split('-').reversed.join('/');
        final time = parts[1].substring(0, 5);
        return '$date  $time';
      }
    } catch (_) {}
    return dateString;
  }
}

class _StatusBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool isDark;

  const _StatusBadge({
    required this.icon,
    required this.label,
    required this.color,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 12.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(10.r),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 14.sp),
          SizedBox(width: 6.w),
          Flexible(
            child: Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12.sp,
                fontWeight: FontWeight.w700,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Party Card ───────────────────────────────────────────────────────────────

class _PartyCard extends StatelessWidget {
  final PartyInfo party;
  final String role;
  final bool isDark;
  final IconData icon;
  final Color iconColor;

  const _PartyCard({
    required this.party,
    required this.role,
    required this.isDark,
    required this.icon,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    final surface =
        isDark ? AppColors.darkSurface : AppColors.lightSurface;
    final border =
        isDark ? AppColors.darkBorder : AppColors.lightBorder;
    final secondaryText = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;

    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 46.w,
            height: 46.w,
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: iconColor, size: 22.sp),
          ),
          SizedBox(width: 14.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  role,
                  style: TextStyle(
                    fontSize: 11.sp,
                    color: secondaryText,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  '${party.firstName} ${party.lastName}',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                ),
                SizedBox(height: 2.h),
                Text(
                  party.phoneNumber,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: secondaryText,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          // Call button
          GestureDetector(
            onTap: () {
              // TODO: launch phone://
              HapticFeedback.lightImpact();
            },
            child: Container(
              width: 38.w,
              height: 38.w,
              decoration: BoxDecoration(
                color: iconColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Icon(Icons.call_outlined,
                  color: iconColor, size: 18.sp),
            ),
          ),
        ],
      ),
    );
  }
}