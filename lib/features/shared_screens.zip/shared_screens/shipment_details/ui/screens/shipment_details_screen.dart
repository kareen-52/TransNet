import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:graduation_progect/core/di/dependency_injection.dart';
import 'package:graduation_progect/features/shared_screens/shipment_details/logic/shipment_details_cubit.dart';
import 'package:graduation_progect/features/shared_screens/shipment_details/logic/shipment_details_state.dart';
import 'package:graduation_progect/features/shared_screens/shipment_details/ui/widgets/shipment_details_content.dart';
import 'package:graduation_progect/core/theming/app_colors.dart';

class ShipmentDetailsScreen extends StatelessWidget {
  final int shipmentId;

  const ShipmentDetailsScreen({super.key, required this.shipmentId});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return BlocProvider(
      create: (context) =>
          getIt<ShipmentDetailsCubit>()..loadShipmentDetails(shipmentId),
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: isDark
            ? SystemUiOverlayStyle.light
            : SystemUiOverlayStyle.dark,
        child: Scaffold(
          backgroundColor: isDark
              ? AppColors.darkBackground
              : AppColors.lightBackground,
          body: BlocBuilder<ShipmentDetailsCubit, ShipmentDetailsState>(
            builder: (context, state) {
              return state.maybeWhen(
                loading: () => const _LoadingView(),
                success: (data) => ShipmentDetailsContent(data: data),
                error: (error) => _ErrorView(message: error.message),
                orElse: () => const SizedBox.shrink(),
              );
            },
          ),
        ),
      ),
    );
  }
}

// ─── Loading ──────────────────────────────────────────────────────────────────

class _LoadingView extends StatelessWidget {
  const _LoadingView();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final shimmerBase =
        isDark ? AppColors.darkSurface : AppColors.lightSurface;
    final shimmerHigh =
        isDark ? AppColors.darkBorder : AppColors.lightBorder;

    return SafeArea(
      child: Column(
        children: [
          // Fake AppBar
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
            child: Row(
              children: [
                _ShimmerBox(w: 40.w, h: 40.w, radius: 12.r,
                    base: shimmerBase, high: shimmerHigh),
                SizedBox(width: 12.w),
                _ShimmerBox(w: 160.w, h: 22.h, radius: 6.r,
                    base: shimmerBase, high: shimmerHigh),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                children: [
                  SizedBox(height: 8.h),
                  _ShimmerBox(w: double.infinity, h: 120.h, radius: 20.r,
                      base: shimmerBase, high: shimmerHigh),
                  SizedBox(height: 20.h),
                  _ShimmerBox(w: double.infinity, h: 80.h, radius: 16.r,
                      base: shimmerBase, high: shimmerHigh),
                  SizedBox(height: 12.h),
                  _ShimmerBox(w: double.infinity, h: 200.h, radius: 16.r,
                      base: shimmerBase, high: shimmerHigh),
                  SizedBox(height: 12.h),
                  _ShimmerBox(w: double.infinity, h: 160.h, radius: 16.r,
                      base: shimmerBase, high: shimmerHigh),
                  SizedBox(height: 12.h),
                  _ShimmerBox(w: double.infinity, h: 120.h, radius: 16.r,
                      base: shimmerBase, high: shimmerHigh),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ShimmerBox extends StatefulWidget {
  final double w, h, radius;
  final Color base, high;
  const _ShimmerBox(
      {required this.w,
      required this.h,
      required this.radius,
      required this.base,
      required this.high});

  @override
  State<_ShimmerBox> createState() => _ShimmerBoxState();
}

class _ShimmerBoxState extends State<_ShimmerBox>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1100))
      ..repeat(reverse: true);
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Container(
        width: widget.w,
        height: widget.h,
        decoration: BoxDecoration(
          color: Color.lerp(widget.base, widget.high, _anim.value),
          borderRadius: BorderRadius.circular(widget.radius),
        ),
      ),
    );
  }
}

// ─── Error ────────────────────────────────────────────────────────────────────

class _ErrorView extends StatelessWidget {
  final String? message;
  const _ErrorView({this.message});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
            child: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              leading: IconButton(
                icon: Icon(Icons.arrow_back_ios_new_rounded, size: 20.sp),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ),
          Expanded(
            child: Center(
              child: Padding(
                padding: EdgeInsets.all(32.w),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 72.w,
                      height: 72.w,
                      decoration: BoxDecoration(
                        color: AppColors.error.withValues(alpha: 0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.error_outline_rounded,
                          color: AppColors.error, size: 36.sp),
                    ),
                    SizedBox(height: 16.h),
                    Text(
                      'حدث خطأ',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      message ?? 'تعذّر تحميل تفاصيل الشحنة',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: AppColors.lightTextSecondary,
                          ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 28.h),
                    FilledButton.icon(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.arrow_back_rounded),
                      label: const Text('العودة'),
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        padding: EdgeInsets.symmetric(
                            horizontal: 28.w, vertical: 14.h),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14.r)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}