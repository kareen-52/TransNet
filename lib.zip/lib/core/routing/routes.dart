class Routes {

  static const String onboardingScreens = '/onboardingScreens';
  static const String login = '/login';
  static const String register = '/register';
  static const String verificationCode = '/verificationCode';

  static const String clientHomeScreen = '/clientHomeScreen';

  static const String driverHomeScreen = '/driverHomeScreen';

  static const String resetPasswordScreen = '/resetPasswordScreen';
  static const String enterEmailScreen = '/enterEmailScreen';

  static const String createShipment = '/createShipment';
  
  static const String mapScreen = '/mapScreen';
  static const String availableDriversScreen = '/availableDriversScreen';
   
  static const String profileClientScreen = '/profileClientScreen';
  static const String profileDriverScreen = '/profileDriverScreen';

  static const String getAllNotifications = '/getAllNotifications';

  static const String waitingDriverScreen = '/waitingDriverScreen';
  static const String driverTrackingScreen = '/driverTrackingScreen';

  static const String shipmentDetailsScreen = '/shipmentDetailsScreen';

  static const String createClientPostScreen = '/createClientPostScreen';
  static const String priceAdjustmentScreen = '/priceAdjustmentScreen';
  
}
